﻿namespace OnlineHomeLoan.Models
{
    public class AdminForm
    {
        public string? AdminEmailID { get; set; }
        public string? AdminPassword { get; set; }
    }
}
