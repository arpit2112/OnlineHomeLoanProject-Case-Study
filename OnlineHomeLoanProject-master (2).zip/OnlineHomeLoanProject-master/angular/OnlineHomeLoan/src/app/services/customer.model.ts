export class Customer {
  customerID: number = 0;

  employement: string = '';

  monthlyIncome: number = 0;

  loanAmount: number = 0;

  firstName: string = '';

  adhaar: string = '';

  pan: string = '';

  status: string = '';
}
